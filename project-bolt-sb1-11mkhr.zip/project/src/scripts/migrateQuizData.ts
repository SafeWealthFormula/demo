import { runMigrations } from '../services/firestore/migrations/migrationRunner';

async function migrate() {
  try {
    console.log('Starting migration process...');
    await runMigrations();
    console.log('Migration completed successfully');
    process.exit(0);
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  }
}

migrate();