import { migrationService } from '../services/firestore/migrations/migrationService';

async function rollback() {
  const targetVersion = process.argv[2] ? parseInt(process.argv[2], 10) : 0;

  try {
    const currentVersion = await migrationService.getCurrentVersion();
    console.log(`Current version: ${currentVersion}`);
    console.log(`Rolling back to version: ${targetVersion}`);

    await migrationService.rollbackToVersion(targetVersion);
    console.log('Rollback completed successfully');
    process.exit(0);
  } catch (error) {
    console.error('Rollback failed:', error);
    process.exit(1);
  }
}

rollback();