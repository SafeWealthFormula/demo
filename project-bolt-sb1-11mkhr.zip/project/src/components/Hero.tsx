import React from 'react';
import QuizButton from './QuizButton';

export default function Hero() {
  return (
    <section className="min-h-screen relative flex items-center pt-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&q=80')] bg-cover bg-center opacity-5"></div>
      
      <div className="relative max-w-4xl mx-auto px-6 py-16 text-center">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-neutral-900 mb-6">
          Could Small Gaps in Your Plan Be{' '}
          <span className="text-primary">Holding You Back?</span>
        </h1>
        
        <p className="text-xl md:text-2xl text-neutral-600 mb-8 leading-relaxed">
          Take 2 minutes to uncover what's working, where adjustments might help, and how to secure your financial future. Your Safe Wealth Score is just the beginning.{' '}
          <span className="font-semibold">Your financial legacy could depend on it.</span>
        </p>

        <QuizButton />
        
        <div className="mt-8 flex items-center justify-center gap-2">
          <div className="w-48 h-2 bg-neutral-200 rounded-full overflow-hidden">
            <div className="w-1/3 h-full bg-primary rounded-full"></div>
          </div>
          <span className="text-sm text-neutral-600">Only 2 minutes</span>
        </div>
      </div>
    </section>
  );
}