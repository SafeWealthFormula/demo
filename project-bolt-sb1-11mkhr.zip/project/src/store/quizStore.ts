import { create } from 'zustand';
import { QuizType, UserAnswer, UserInfo } from '../types/quiz';

interface QuizState {
  view: 'landing' | 'quiz-selection' | 'quiz' | 'expansion' | 'loading' | 'extended-quiz' | 'lead-capture' | 'results';
  quizType: QuizType | null;
  currentQuestionIndex: number;
  userAnswers: UserAnswer[];
  userInfo: UserInfo;
  abTestVariant: 'A' | 'B' | 'C' | 'D' | 'E' | 'F';
  isKeyboardNavigation: boolean;
  setView: (view: QuizState['view']) => void;
  setQuizType: (type: QuizType | null) => void;
  setAnswer: (answer: UserAnswer) => void;
  setUserInfo: (info: Partial<UserInfo>) => void;
  nextQuestion: () => void;
  resetQuiz: () => void;
  startQuiz: () => void;
  cycleVariant: () => void;
  setKeyboardNavigation: (value: boolean) => void;
}

export const useQuizStore = create<QuizState>((set) => ({
  view: 'landing',
  quizType: null,
  currentQuestionIndex: 0,
  userAnswers: [],
  userInfo: {},
  abTestVariant: Math.random() < 0.166 ? 'A' : 
                 Math.random() < 0.333 ? 'B' : 
                 Math.random() < 0.5 ? 'C' : 
                 Math.random() < 0.666 ? 'D' :
                 Math.random() < 0.833 ? 'E' : 'F',
  isKeyboardNavigation: false,
  
  setView: (view) => set({ view }),
  
  setQuizType: (type) => set((state) => {
    if (!type) {
      return {
        quizType: null,
        currentQuestionIndex: 0,
        userAnswers: [],
        userInfo: {},
        view: 'quiz-selection'
      };
    }

    // When setting extended quiz type, transition through loading
    if (type === 'extended') {
      return {
        quizType: type,
        currentQuestionIndex: 0,
        userAnswers: [],
        userInfo: { ...state.userInfo, quizType: type },
        view: 'loading'
      };
    }
    
    return {
      quizType: type,
      currentQuestionIndex: 0,
      userAnswers: [],
      userInfo: { ...state.userInfo, quizType: type },
      view: 'quiz'
    };
  }),
  
  setAnswer: (answer) => set((state) => {
    const newAnswers = [...state.userAnswers, answer];
    const totalQuestions = state.quizType === 'quick' ? 8 : 
                          state.quizType === 'standard' ? 12 : 
                          state.quizType === 'extended' ? 5 : 0;

    if (newAnswers.length === totalQuestions) {
      return {
        userAnswers: newAnswers,
        view: state.quizType === 'extended' ? 'lead-capture' : 'expansion'
      };
    }

    return {
      userAnswers: newAnswers,
      currentQuestionIndex: state.currentQuestionIndex + 1
    };
  }),
  
  setUserInfo: (info) => set((state) => {
    const newInfo = { ...state.userInfo, ...info };
    
    if (info.showLeadCapture) {
      return {
        userInfo: newInfo,
        view: 'lead-capture'
      };
    }

    if (info.email || info.phone) {
      return {
        userInfo: newInfo,
        view: 'results'
      };
    }

    return { userInfo: newInfo };
  }),
  
  nextQuestion: () => set((state) => ({
    currentQuestionIndex: state.currentQuestionIndex + 1
  })),
  
  resetQuiz: () => set({
    view: 'landing',
    quizType: null,
    currentQuestionIndex: 0,
    userAnswers: [],
    userInfo: {}
  }),

  startQuiz: () => set({
    view: 'quiz-selection',
    quizType: null,
    currentQuestionIndex: 0,
    userAnswers: [],
    userInfo: {}
  }),

  cycleVariant: () => set((state) => ({
    abTestVariant: state.abTestVariant === 'A' ? 'B' : 
                   state.abTestVariant === 'B' ? 'C' : 
                   state.abTestVariant === 'C' ? 'D' :
                   state.abTestVariant === 'D' ? 'E' :
                   state.abTestVariant === 'E' ? 'F' : 'A'
  })),

  setKeyboardNavigation: (value) => set({
    isKeyboardNavigation: value
  })
}));