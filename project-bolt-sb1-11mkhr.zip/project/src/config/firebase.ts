import { initializeApp } from 'firebase/app';
import { getFirestore, setLogLevel } from 'firebase/firestore';

// Enable debug logging in development
if (import.meta.env.DEV) {
  setLogLevel('debug');
}

const firebaseConfig = {
  apiKey: "AIzaSyA3DH7YKdeGQ77ImSZpDoimJGAp6gnn8Bs",
  authDomain: "safewealthformula.firebaseapp.com",
  projectId: "safewealthformula",
  storageBucket: "safewealthformula.firebasestorage.app",
  messagingSenderId: "1090618965859",
  appId: "1:1090618965859:web:85f7bc9dea390ce8611d56"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);

// Initialize Firestore
export const db = getFirestore(app);