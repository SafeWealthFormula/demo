import { db } from '../../config/firebase';
import { collection, writeBatch, doc, getDocs, query, where, serverTimestamp } from 'firebase/firestore';
import { quickQuizQuestions, standardQuizQuestions } from '../../data/questions';

async function checkExistingData(): Promise<boolean> {
  try {
    const questionsRef = collection(db, 'questions');
    const q = query(questionsRef, where('quizType', '==', 'quick'));
    const snapshot = await getDocs(q);
    return !snapshot.empty;
  } catch (error) {
    console.error('Error checking existing data:', error);
    return false;
  }
}

export async function migrateQuestions(): Promise<void> {
  try {
    // Check if data already exists
    const hasData = await checkExistingData();
    if (hasData) {
      console.log('Questions already exist, skipping migration');
      return;
    }

    const batch = writeBatch(db);
    const questionsRef = collection(db, 'questions');

    // Migrate quick quiz questions
    quickQuizQuestions.forEach((question, index) => {
      const docRef = doc(questionsRef);
      batch.set(docRef, {
        ...question,
        quizType: 'quick',
        order: index,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    });

    // Migrate standard quiz questions
    standardQuizQuestions.forEach((question, index) => {
      const docRef = doc(questionsRef);
      batch.set(docRef, {
        ...question,
        quizType: 'standard',
        order: index,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    });

    await batch.commit();
    console.log('Questions migrated successfully');
  } catch (error) {
    console.error('Error migrating questions:', error);
    throw error;
  }
}