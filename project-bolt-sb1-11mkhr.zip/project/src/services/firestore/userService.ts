import { 
  doc,
  setDoc,
  getDoc,
  updateDoc,
  serverTimestamp 
} from 'firebase/firestore';
import { collections } from './collections';
import type { UserDocument } from './schemas';

export class UserService {
  async createUser(userId: string, email: string): Promise<void> {
    try {
      const userRef = doc(collections.users, userId);
      await setDoc(userRef, {
        email,
        createdAt: serverTimestamp(),
        lastActive: serverTimestamp()
      });
    } catch (error) {
      console.error('Error creating user:', error);
      throw error;
    }
  }

  async updateUserProfile(userId: string, profile: Partial<UserDocument['profile']>): Promise<void> {
    try {
      const userRef = doc(collections.users, userId);
      await updateDoc(userRef, {
        profile,
        lastActive: serverTimestamp()
      });
    } catch (error) {
      console.error('Error updating user profile:', error);
      throw error;
    }
  }

  async getUser(userId: string): Promise<UserDocument | null> {
    try {
      const userRef = doc(collections.users, userId);
      const userSnap = await getDoc(userRef);
      
      if (!userSnap.exists()) {
        return null;
      }

      return {
        id: userSnap.id,
        ...userSnap.data()
      } as UserDocument;
    } catch (error) {
      console.error('Error fetching user:', error);
      throw error;
    }
  }
}

export const userService = new UserService();