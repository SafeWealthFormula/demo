import { db } from '../../config/firebase';
import { collection, getDocs, query, where, writeBatch, doc, limit } from 'firebase/firestore';
import { quickQuizQuestions, standardQuizQuestions } from '../../data/questions';

async function checkConnection(): Promise<boolean> {
  try {
    const testRef = collection(db, 'questions');
    const q = query(testRef, limit(1));
    await getDocs(q);
    return true;
  } catch (error) {
    console.error('Firestore connection test failed:', error);
    return false;
  }
}

async function checkExistingData(): Promise<boolean> {
  try {
    const questionsRef = collection(db, 'questions');
    const q = query(questionsRef, where('quizType', '==', 'quick'));
    const snapshot = await getDocs(q);
    return !snapshot.empty;
  } catch (error) {
    console.error('Error checking existing data:', error);
    return false; // Return false on error to trigger data initialization
  }
}

async function migrateQuestions(): Promise<void> {
  const batch = writeBatch(db);
  const questionsRef = collection(db, 'questions');

  // Migrate quick quiz questions
  quickQuizQuestions.forEach((question, index) => {
    const docRef = doc(questionsRef);
    batch.set(docRef, {
      ...question,
      quizType: 'quick',
      order: index,
      createdAt: new Date(),
      updatedAt: new Date()
    });
  });

  // Migrate standard quiz questions
  standardQuizQuestions.forEach((question, index) => {
    const docRef = doc(questionsRef);
    batch.set(docRef, {
      ...question,
      quizType: 'standard',
      order: index,
      createdAt: new Date(),
      updatedAt: new Date()
    });
  });

  await batch.commit();
}

export async function initializeDatabase(): Promise<void> {
  try {
    // Test connection first
    const isConnected = await checkConnection();
    if (!isConnected) {
      throw new Error('Cannot connect to Firestore');
    }

    // Check if data needs to be initialized
    const hasData = await checkExistingData();
    if (!hasData) {
      await migrateQuestions();
    }
  } catch (error) {
    console.error('Database initialization failed:', error);
    throw error;
  }
}