import { 
  doc,
  setDoc,
  addDoc,
  collection,
  writeBatch,
  serverTimestamp
} from 'firebase/firestore';
import { db } from '../../config/firebase';
import { UserAnswer } from '../../types/quiz';

export class QuizService {
  async createSubmission(quizType: 'quick' | 'standard'): Promise<string> {
    try {
      const submission = {
        quizType,
        startedAt: serverTimestamp(),
        status: 'in_progress'
      };

      const submissionRef = collection(db, 'submissions');
      const docRef = await addDoc(submissionRef, submission);
      return docRef.id;
    } catch (error) {
      console.error('Error creating submission:', error);
      throw error;
    }
  }

  async submitQuizResponse(
    submissionId: string,
    response: UserAnswer
  ): Promise<void> {
    try {
      const batch = writeBatch(db);
      
      // Add response to submission
      const responseRef = doc(db, `submissions/${submissionId}/responses/${response.questionId}`);
      batch.set(responseRef, {
        ...response,
        timestamp: serverTimestamp()
      });

      // Update submission metadata
      const submissionRef = doc(db, `submissions/${submissionId}`);
      batch.update(submissionRef, {
        lastUpdated: serverTimestamp()
      });

      await batch.commit();
    } catch (error) {
      console.error('Error submitting response:', error);
      throw error;
    }
  }

  async completeSubmission(submissionId: string, userInfo: { email?: string; phone?: string }): Promise<void> {
    try {
      const submissionRef = doc(db, `submissions/${submissionId}`);
      await setDoc(submissionRef, {
        completedAt: serverTimestamp(),
        status: 'completed',
        userInfo
      }, { merge: true });
    } catch (error) {
      console.error('Error completing submission:', error);
      throw error;
    }
  }
}

export const quizService = new QuizService();