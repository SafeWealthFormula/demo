import { 
  collection, 
  doc, 
  getDoc, 
  setDoc, 
  query, 
  where, 
  getDocs,
  serverTimestamp 
} from 'firebase/firestore';
import { db } from '../../config/firebase';
import { QuizFlag, UserAnswer } from '../../types/quiz';
import { collections } from './collections';

export interface QuizFlowQuestion {
  id: string;
  text: string;
  type: 'primary' | 'secondary';
  tag: string;
  flag: string;
}

export interface QuizFlow {
  userId: string;
  questions: QuizFlowQuestion[];
  createdAt: Date;
  updatedAt: Date;
}

export class QuizFlowService {
  private shouldSkipQuestion(tag: string, flag: string, userFlags: QuizFlag[]): boolean {
    // Skip redundant questions based on flag combinations
    if (tag === 'QQ1' && flag === 'green' && 
        userFlags.some(f => f.area === 'emergency' && f.type === 'green')) {
      return true;
    }

    if (tag === 'QQ7' && flag === 'green' && 
        userFlags.some(f => f.area === 'advisor' && f.type === 'green')) {
      return true;
    }

    return false;
  }

  private getConsolidatedQuestion(tag: string, flag: string, userAnswers: UserAnswer[]): QuizFlowQuestion | null {
    if (tag === 'QQ6' && flag === 'green' && 
        userAnswers.some(a => a.questionId === 'QQ7' && a.answerId.includes('QQA7.1'))) {
      return {
        id: 'CQ1',
        text: 'How do you align your retirement and tax strategies to protect and grow your savings?',
        type: 'primary',
        tag: 'QQ6',
        flag: 'green'
      };
    }

    return null;
  }

  async computeQuizFlow(
    userId: string, 
    userFlags: QuizFlag[], 
    userAnswers: UserAnswer[]
  ): Promise<void> {
    try {
      const questions: QuizFlowQuestion[] = [];

      // Process each flag to determine questions
      for (const flag of userFlags) {
        const baseQuestions = await this.getQuestionsForFlag(flag);
        
        for (const question of baseQuestions) {
          if (!this.shouldSkipQuestion(question.tag, flag.type, userFlags)) {
            const consolidatedQuestion = this.getConsolidatedQuestion(
              question.tag, 
              flag.type, 
              userAnswers
            );

            questions.push(consolidatedQuestion || question);
          }
        }
      }

      // Save computed flow
      const quizFlow: QuizFlow = {
        userId,
        questions,
        createdAt: new Date(),
        updatedAt: new Date()
      };

      await setDoc(doc(collections.quizFlows, userId), {
        ...quizFlow,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });

    } catch (error) {
      console.error('Error computing quiz flow:', error);
      throw error;
    }
  }

  private async getQuestionsForFlag(flag: QuizFlag): Promise<QuizFlowQuestion[]> {
    try {
      const q = query(
        collection(db, 'extended-questions'),
        where('area', '==', flag.area),
        where('flag', '==', flag.type)
      );

      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as QuizFlowQuestion[];
    } catch (error) {
      console.error('Error fetching questions for flag:', error);
      throw error;
    }
  }

  async getUserQuizFlow(userId: string): Promise<QuizFlow | null> {
    try {
      const docRef = doc(collections.quizFlows, userId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        return null;
      }

      return {
        ...docSnap.data(),
        createdAt: docSnap.data().createdAt.toDate(),
        updatedAt: docSnap.data().updatedAt.toDate()
      } as QuizFlow;
    } catch (error) {
      console.error('Error fetching user quiz flow:', error);
      throw error;
    }
  }
}

export const quizFlowService = new QuizFlowService();