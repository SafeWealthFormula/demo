import { addDoc, serverTimestamp } from 'firebase/firestore';
import { collections } from './collections';
import type { AnalyticsDocument } from './schemas';

export class AnalyticsService {
  async trackEvent(
    type: AnalyticsDocument['type'],
    data: Record<string, any>
  ): Promise<void> {
    try {
      await addDoc(collections.analytics, {
        type,
        timestamp: serverTimestamp(),
        data
      });
    } catch (error) {
      console.error('Error tracking analytics event:', error);
      // Fail silently in production
    }
  }
}

export const analyticsService = new AnalyticsService();