import { db } from '../../config/firebase';
import { collection, getDocs, query, limit, doc, setDoc, writeBatch, serverTimestamp } from 'firebase/firestore';
import { quickQuizQuestions, standardQuizQuestions } from '../../data/quizData';

export async function initializeFirestore(): Promise<boolean> {
  try {
    // Test connection
    const testRef = doc(collection(db, 'test-connection'), 'test-doc');
    await setDoc(testRef, {
      timestamp: serverTimestamp(),
      test: true
    });

    // Initialize questions if needed
    const questionsRef = collection(db, 'questions');
    const q = query(questionsRef, limit(1));
    const snapshot = await getDocs(q);
    
    if (snapshot.empty) {
      const batch = writeBatch(db);

      // Add quick quiz questions
      quickQuizQuestions.forEach((question, index) => {
        const docRef = doc(questionsRef);
        batch.set(docRef, {
          ...question,
          quizType: 'quick',
          order: index,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
      });

      // Add standard quiz questions
      standardQuizQuestions.forEach((question, index) => {
        const docRef = doc(questionsRef);
        batch.set(docRef, {
          ...question,
          quizType: 'standard',
          order: index,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
      });

      await batch.commit();
    }

    return true;
  } catch (error) {
    console.error('Firestore initialization failed:', error);
    return false;
  }
}