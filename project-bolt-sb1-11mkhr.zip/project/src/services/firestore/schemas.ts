export interface FirestoreTimestamp {
  seconds: number;
  nanoseconds: number;
}

export interface UserDocument {
  id: string;
  email: string;
  createdAt: FirestoreTimestamp;
  lastActive: FirestoreTimestamp;
  profile?: {
    name?: string;
    phone?: string;
    preferences?: {
      notifications: boolean;
      marketingEmails: boolean;
    }
  }
}

export interface QuizDocument {
  id: string;
  type: 'quick' | 'standard';
  version: number;
  createdAt: FirestoreTimestamp;
  updatedAt: FirestoreTimestamp;
  questions: Array<{
    id: string;
    text: string;
    type: 'single' | 'multiple';
    answers: Array<{
      id: string;
      text: string;
    }>
  }>
}

export interface SubmissionDocument {
  id: string;
  userId: string;
  quizId: string;
  quizType: 'quick' | 'standard';
  startedAt: FirestoreTimestamp;
  completedAt: FirestoreTimestamp;
  responses: Array<{
    questionId: string;
    answerId: string[];
    timestamp: FirestoreTimestamp;
  }>;
  analysis?: {
    riskScore?: number;
    wealthProtectionScore?: number;
    recommendations?: string[];
  }
}

export interface AnalyticsDocument {
  id: string;
  type: 'quiz_completion' | 'user_engagement' | 'recommendation_action';
  timestamp: FirestoreTimestamp;
  data: Record<string, any>;
}