import { db } from '../../config/firebase';
import { collection, getDocs, query, limit, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { setLogLevel } from 'firebase/firestore';

// Enable debug logging in development
if (import.meta.env.DEV) {
  setLogLevel('debug');
}

async function testConnection(): Promise<boolean> {
  try {
    // Test connection with a simple query
    const testRef = collection(db, 'test-connection');
    const q = query(testRef, limit(1));
    await getDocs(q);
    console.log('Firestore connection successful');
    return true;
  } catch (error) {
    console.error('Firestore connection test failed:', error);
    return false;
  }
}

export async function initializeFirestore(): Promise<boolean> {
  try {
    // First test connection
    const isConnected = await testConnection();
    if (!isConnected) {
      throw new Error('Could not establish Firestore connection');
    }

    // Initialize test document to verify write access
    const testRef = doc(collection(db, 'test-connection'), 'test-doc');
    await setDoc(testRef, {
      timestamp: serverTimestamp(),
      test: true
    });

    return true;
  } catch (error) {
    console.error('Firestore initialization failed:', error);
    return false;
  }
}