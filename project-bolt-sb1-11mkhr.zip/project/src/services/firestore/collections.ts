import { collection } from 'firebase/firestore';
import { db } from '../../config/firebase';

export const collections = {
  users: collection(db, 'users'),
  quizzes: collection(db, 'quizzes'),
  submissions: collection(db, 'submissions'),
  analytics: collection(db, 'analytics'),
  quizFlows: collection(db, 'quiz-flows'),
  extendedQuestions: collection(db, 'extended-questions')
} as const;

export const collectionPaths = {
  users: 'users',
  quizzes: 'quizzes',
  submissions: 'submissions',
  analytics: 'analytics',
  quizFlows: 'quiz-flows',
  extendedQuestions: 'extended-questions',
  userSubmissions: 'users/{userId}/submissions',
  quizResponses: 'submissions/{submissionId}/responses'
} as const;