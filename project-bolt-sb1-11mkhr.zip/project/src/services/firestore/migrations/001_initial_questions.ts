import { Migration } from './types';
import { collection, writeBatch, doc } from 'firebase/firestore';
import { db } from '../../../config/firebase';
import { quickQuizQuestions, standardQuizQuestions } from '../../../data/questions';

export const initialQuestionsMigration: Migration = {
  id: '001_initial_questions',
  version: 1,
  description: 'Initial migration of quiz questions',
  
  async up() {
    const batch = writeBatch(db);
    const questionsRef = collection(db, 'questions');

    // Migrate quick quiz questions
    quickQuizQuestions.forEach((question, index) => {
      const docRef = doc(questionsRef);
      batch.set(docRef, {
        ...question,
        quizType: 'quick',
        order: index,
        createdAt: new Date(),
        updatedAt: new Date()
      });
    });

    // Migrate standard quiz questions
    standardQuizQuestions.forEach((question, index) => {
      const docRef = doc(questionsRef);
      batch.set(docRef, {
        ...question,
        quizType: 'standard',
        order: index,
        createdAt: new Date(),
        updatedAt: new Date()
      });
    });

    await batch.commit();
  },

  async down() {
    // This is a destructive operation - only use in development
    const batch = writeBatch(db);
    const questionsRef = collection(db, 'questions');
    const snapshot = await getDocs(questionsRef);
    
    snapshot.docs.forEach(doc => {
      batch.delete(doc.ref);
    });

    await batch.commit();
  }
};