import { 
  collection, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  limit,
  doc,
  setDoc,
  serverTimestamp,
  runTransaction
} from 'firebase/firestore';
import { db } from '../../../config/firebase';
import { migrations } from './index';

export async function runMigrations(): Promise<void> {
  try {
    console.log('Migration Step 1: Starting migration process...');
    
    // Initialize migrations collection if needed
    const migrationDoc = doc(collection(db, 'migrations'), 'metadata');
    
    await runTransaction(db, async (transaction) => {
      console.log('Migration Step 2: Checking migration metadata...');
      const snapshot = await transaction.get(migrationDoc);
      
      if (!snapshot.exists()) {
        console.log('Migration Step 3: Initializing migration metadata...');
        transaction.set(migrationDoc, {
          currentVersion: 0,
          initialized: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
      }
    });

    // Get current version
    console.log('Migration Step 4: Fetching current database version...');
    const migrationsRef = collection(db, 'migrations');
    const q = query(
      migrationsRef,
      where('status', '==', 'completed'),
      orderBy('version', 'desc'),
      limit(1)
    );
    
    const snapshot = await getDocs(q);
    const currentVersion = snapshot.empty ? 0 : snapshot.docs[0].data().version;

    console.log(`Migration Step 5: Current database version: ${currentVersion}`);

    // Get pending migrations
    const pendingMigrations = migrations
      .filter(m => m.version > currentVersion)
      .sort((a, b) => a.version - b.version);

    if (pendingMigrations.length === 0) {
      console.log('Migration Step 6: Database is up to date, no migrations needed');
      return;
    }

    // Run migrations in order
    console.log(`Migration Step 7: Running ${pendingMigrations.length} migrations...`);
    
    for (const migration of pendingMigrations) {
      try {
        console.log(`Migration Step 8: Starting migration ${migration.id}...`);
        
        // Create migration record
        const migrationRef = doc(migrationsRef, migration.id);
        await setDoc(migrationRef, {
          id: migration.id,
          version: migration.version,
          description: migration.description,
          status: 'in_progress',
          startedAt: serverTimestamp()
        });

        console.log(`Migration Step 9: Executing migration ${migration.id}...`);
        // Run migration
        await migration.up();

        console.log(`Migration Step 10: Completing migration ${migration.id}...`);
        // Mark as completed
        await setDoc(migrationRef, {
          status: 'completed',
          completedAt: serverTimestamp()
        }, { merge: true });

        console.log(`Migration Step 11: Migration ${migration.id} completed successfully`);
      } catch (error) {
        console.error(`Migration Step ERROR: Failed during migration ${migration.id}`);
        
        // Mark as failed
        await setDoc(doc(migrationsRef, migration.id), {
          status: 'failed',
          error: error instanceof Error ? error.message : 'Unknown error',
          failedAt: serverTimestamp()
        }, { merge: true });

        throw error;
      }
    }

    console.log('Migration Step 12: All migrations completed successfully');
  } catch (error) {
    console.error('Migration Step ERROR: Migration process failed:', error);
    throw error;
  }
}