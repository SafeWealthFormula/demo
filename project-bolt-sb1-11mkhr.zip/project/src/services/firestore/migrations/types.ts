export interface Migration {
  id: string;
  version: number;
  description: string;
  up: () => Promise<void>;
  down: () => Promise<void>;
}