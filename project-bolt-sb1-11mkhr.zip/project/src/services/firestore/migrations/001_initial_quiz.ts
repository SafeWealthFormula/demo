import { Migration } from './types';
import { collection, writeBatch, doc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../../config/firebase';

const quickQuizData = {
  id: "quickQuiz",
  description: "Complete Quick Quiz (QQ1–QQ8) with all questions, tags, and flag mappings",
  questions: [
    {
      id: "QQ1",
      tag: "QQ1",
      text: "If your income stopped tomorrow, how long could you maintain your lifestyle?",
      options: [
        {text: "More than 6 months—I have a solid safety net.", flag: "Green"},
        {text: "3–6 months—I'd feel some strain but manage.", flag: "Yellow 1"},
        {text: "1–3 months—I'd need to make big adjustments.", flag: "Yellow 2"},
        {text: "Less than 1 month—I'd need immediate help.", flag: "Red"}
      ]
    },
    // ... rest of the questions
  ]
};

export const initialQuizMigration: Migration = {
  id: '001_initial_quiz',
  version: 1,
  description: 'Initial quiz data setup',
  
  async up() {
    const batch = writeBatch(db);

    // Create quiz document
    const quizRef = doc(collection(db, 'quizzes'), 'quickQuiz');
    batch.set(quizRef, {
      id: quickQuizData.id,
      description: quickQuizData.description,
      version: 1,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    // Create questions collection
    const questionsRef = collection(db, 'questions');
    quickQuizData.questions.forEach((question, index) => {
      const questionRef = doc(questionsRef);
      batch.set(questionRef, {
        ...question,
        quizId: 'quickQuiz',
        order: index,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    });

    await batch.commit();
  },

  async down() {
    const batch = writeBatch(db);
    
    // Delete quiz document
    const quizRef = doc(collection(db, 'quizzes'), 'quickQuiz');
    batch.delete(quizRef);

    // Delete questions
    const questionsRef = collection(db, 'questions');
    const snapshot = await getDocs(query(questionsRef, where('quizId', '==', 'quickQuiz')));
    snapshot.docs.forEach(doc => batch.delete(doc.ref));

    await batch.commit();
  }
};