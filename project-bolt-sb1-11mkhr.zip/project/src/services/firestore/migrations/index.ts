import { initialQuestionsMigration } from './001_initial_questions';
import { extendedQuestionsMigration } from './002_extended_questions';
import type { Migration } from './types';

export const migrations: Migration[] = [
  initialQuestionsMigration,
  extendedQuestionsMigration
];

export * from './types';
export * from './migrationService';