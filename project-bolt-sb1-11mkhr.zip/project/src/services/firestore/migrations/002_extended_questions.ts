import { Migration } from './types';
import { collection, writeBatch, doc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../../config/firebase';

const extendedQuizData = {
  id: "extendedQuiz",
  type: "extended",
  version: 1,
  questions: [
    {
      id: "EQ1",
      text: "What would give you the most confidence in handling a long-term income disruption?",
      type: "multiple",
      area: "income",
      flag: "red",
      order: 1,
      answers: [
        { 
          id: "EQA1.1", 
          text: "Knowing I have resources that grow even when I'm not earning."
        },
        { 
          id: "EQA1.2", 
          text: "Feeling assured my savings could cover a long-term challenge."
        },
        { 
          id: "EQA1.3", 
          text: "Having a backup plan that doesn't rely solely on savings."
        },
        { 
          id: "EQA1.4", 
          text: "Understanding strategies to strengthen my financial safety net."
        }
      ]
    }
    // Add remaining extended questions
  ]
};

export const extendedQuizMigration: Migration = {
  id: '002_extended_questions',
  version: 2,
  description: 'Add extended quiz questions',
  
  async up() {
    const batch = writeBatch(db);

    // Create quiz metadata
    const quizRef = doc(collection(db, 'quizzes'), extendedQuizData.id);
    batch.set(quizRef, {
      id: extendedQuizData.id,
      type: extendedQuizData.type,
      version: extendedQuizData.version,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    // Create questions
    const questionsRef = collection(db, 'questions');
    extendedQuizData.questions.forEach((question) => {
      const questionRef = doc(questionsRef);
      batch.set(questionRef, {
        ...question,
        quizId: extendedQuizData.id,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    });

    await batch.commit();
  },

  async down() {
    const batch = writeBatch(db);
    
    // Delete quiz metadata
    const quizRef = doc(collection(db, 'quizzes'), extendedQuizData.id);
    batch.delete(quizRef);

    // Delete questions
    const questionsRef = collection(db, 'questions');
    const snapshot = await getDocs(query(
      questionsRef, 
      where('quizId', '==', extendedQuizData.id)
    ));
    
    snapshot.docs.forEach(doc => batch.delete(doc.ref));
    await batch.commit();
  }
};