import { Migration } from './types';
import { collection, writeBatch, doc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../../config/firebase';

const quickQuizData = {
  id: "quickQuiz",
  type: "quick",
  version: 1,
  questions: [
    {
      id: "QQ1",
      text: "If your income stopped tomorrow, how long could you maintain your lifestyle?",
      type: "single",
      area: "income",
      order: 1,
      answers: [
        { 
          id: "QQA1.1", 
          text: "More than 6 months—I have a solid safety net.",
          flag: "green"
        },
        { 
          id: "QQA1.2", 
          text: "3–6 months—I'd feel some strain but manage.",
          flag: "yellow1"
        },
        { 
          id: "QQA1.3", 
          text: "1–3 months—I'd need to make big adjustments.",
          flag: "yellow2"
        },
        { 
          id: "QQA1.4", 
          text: "Less than 1 month—I'd need immediate help.",
          flag: "red"
        }
      ]
    },
    // Add remaining questions with similar structure
  ]
};

export const initialQuizMigration: Migration = {
  id: '001_quiz_data',
  version: 1,
  description: 'Initial quiz data setup',
  
  async up() {
    const batch = writeBatch(db);

    // Create quiz metadata
    const quizRef = doc(collection(db, 'quizzes'), quickQuizData.id);
    batch.set(quizRef, {
      id: quickQuizData.id,
      type: quickQuizData.type,
      version: quickQuizData.version,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    // Create questions
    const questionsRef = collection(db, 'questions');
    quickQuizData.questions.forEach((question) => {
      const questionRef = doc(questionsRef);
      batch.set(questionRef, {
        ...question,
        quizId: quickQuizData.id,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    });

    await batch.commit();
  },

  async down() {
    const batch = writeBatch(db);
    
    // Delete quiz metadata
    const quizRef = doc(collection(db, 'quizzes'), quickQuizData.id);
    batch.delete(quizRef);

    // Delete questions
    const questionsRef = collection(db, 'questions');
    const snapshot = await getDocs(query(
      questionsRef, 
      where('quizId', '==', quickQuizData.id)
    ));
    
    snapshot.docs.forEach(doc => batch.delete(doc.ref));
    await batch.commit();
  }
};