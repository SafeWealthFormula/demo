import { 
  collection, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  limit,
  doc,
  setDoc,
  serverTimestamp,
  runTransaction
} from 'firebase/firestore';
import { db } from '../../../config/firebase';
import { Migration } from './types';

class MigrationService {
  private migrationsCollection = collection(db, 'migrations');

  async getCurrentVersion(): Promise<number> {
    try {
      // First ensure migrations collection exists
      const migrationDoc = doc(this.migrationsCollection, 'metadata');
      
      await runTransaction(db, async (transaction) => {
        const snapshot = await transaction.get(migrationDoc);
        
        if (!snapshot.exists()) {
          transaction.set(migrationDoc, {
            currentVersion: 0,
            initialized: true,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          });
        }
      });

      // Get latest version
      const snapshot = await getDocs(this.migrationsCollection);
      if (snapshot.empty) return 0;

      let latestVersion = 0;
      snapshot.docs.forEach(doc => {
        const data = doc.data();
        if (data.status === 'completed' && data.version > latestVersion) {
          latestVersion = data.version;
        }
      });

      return latestVersion;
    } catch (error) {
      console.error('Error getting current version:', error);
      throw error;
    }
  }

  async applyMigration(migration: Migration): Promise<void> {
    const migrationRef = doc(this.migrationsCollection, migration.id);

    try {
      // Start migration
      await setDoc(migrationRef, {
        id: migration.id,
        version: migration.version,
        description: migration.description,
        status: 'in_progress',
        startedAt: serverTimestamp()
      });

      // Run migration
      await migration.up();

      // Mark as completed
      await setDoc(migrationRef, {
        status: 'completed',
        completedAt: serverTimestamp()
      }, { merge: true });

    } catch (error) {
      // Mark as failed
      await setDoc(migrationRef, {
        status: 'failed',
        error: error instanceof Error ? error.message : 'Unknown error',
        failedAt: serverTimestamp()
      }, { merge: true });

      throw error;
    }
  }
}

export const migrationService = new MigrationService();