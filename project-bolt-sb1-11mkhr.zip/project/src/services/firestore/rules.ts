export const firestoreRules = `
rules_version = '2';

service cloud.firestore {
  match /databases/{database}/documents {
    // Helper functions
    function isAuthenticated() {
      return request.auth != null;
    }
    
    function isOwner(userId) {
      return request.auth.uid == userId;
    }

    // Quiz flows
    match /quiz-flows/{userId} {
      allow read: if isAuthenticated() && isOwner(userId);
      allow write: if isAuthenticated() && isOwner(userId);
    }
    
    // Extended questions
    match /extended-questions/{questionId} {
      allow read: if isAuthenticated();
    }
    
    // Allow read access to questions and quizzes
    match /questions/{questionId} {
      allow read: if true;
    }
    
    match /quizzes/{quizId} {
      allow read: if true;
    }
    
    // Allow quiz submissions
    match /submissions/{submissionId} {
      allow create: if isAuthenticated();
      allow read: if isAuthenticated() && isOwner(resource.data.userId);
      
      match /responses/{responseId} {
        allow create: if isAuthenticated();
        allow read: if isAuthenticated() && isOwner(get(/databases/$(database)/documents/submissions/$(submissionId)).data.userId);
      }
    }
  }
}`;