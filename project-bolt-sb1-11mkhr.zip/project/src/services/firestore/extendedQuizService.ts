import { collection, getDocs, query, where, orderBy } from 'firebase/firestore';
import { db } from '../../config/firebase';
import { Question } from '../../types/quiz';
import { collections } from './collections';

export class ExtendedQuizService {
  async getExtendedQuestions(): Promise<Question[]> {
    try {
      const q = query(
        collection(db, 'EQ Complete'),
        orderBy('order', 'asc')
      );

      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Question[];
    } catch (error) {
      console.error('Error fetching extended questions:', error);
      throw error;
    }
  }
}

export const extendedQuizService = new ExtendedQuizService();