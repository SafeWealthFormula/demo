import { collection, query, where, orderBy, getDocs } from 'firebase/firestore';
import { db } from '../../config/firebase';
import { Question } from '../../types/quiz';

export class QuestionService {
  async getQuestionsByType(quizType: 'quick' | 'standard'): Promise<Question[]> {
    try {
      const q = query(
        collection(db, 'questions'),
        where('quizType', '==', quizType),
        orderBy('order', 'asc')
      );

      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Question[];
    } catch (error) {
      console.error('Error fetching questions:', error);
      throw error;
    }
  }
}

export const questionService = new QuestionService();