import { create } from 'zustand';
import { QuizType, UserAnswer } from '../types/quiz';

interface QuizFlowState {
  currentStep: 'initial' | 'quick' | 'standard' | 'extended' | 'complete';
  quizType: QuizType | null;
  answers: UserAnswer[];
  setStep: (step: QuizFlowState['currentStep']) => void;
  setQuizType: (type: QuizType | null) => void;
  addAnswer: (answer: UserAnswer) => void;
  reset: () => void;
}

export const useQuizFlow = create<QuizFlowState>((set) => ({
  currentStep: 'initial',
  quizType: null,
  answers: [],

  setStep: (step) => set({ currentStep: step }),
  
  setQuizType: (type) => set({ 
    quizType: type,
    currentStep: type ? type : 'initial'
  }),
  
  addAnswer: (answer) => set((state) => ({
    answers: [...state.answers, answer]
  })),
  
  reset: () => set({
    currentStep: 'initial',
    quizType: null,
    answers: []
  })
}));