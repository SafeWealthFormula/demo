import { 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  where,
  DocumentData 
} from 'firebase/firestore';
import { db } from '../config/firebase';
import { UserAnswer, UserInfo } from '../types/quiz';

export interface QuizSubmission {
  answers: UserAnswer[];
  userInfo: UserInfo;
  timestamp: Date;
}

export const quizService = {
  async submitQuiz(answers: UserAnswer[], userInfo: UserInfo): Promise<string> {
    try {
      const submission: QuizSubmission = {
        answers,
        userInfo,
        timestamp: new Date()
      };

      const docRef = await addDoc(collection(db, 'quiz-submissions'), submission);
      return docRef.id;
    } catch (error) {
      console.error('Error submitting quiz:', error);
      throw error;
    }
  },

  async getUserSubmissions(email: string): Promise<QuizSubmission[]> {
    try {
      const q = query(
        collection(db, 'quiz-submissions'),
        where('userInfo.email', '==', email)
      );

      const querySnapshot = await getDocs(q);
      return querySnapshot.docs.map(doc => ({
        ...doc.data(),
        timestamp: doc.data().timestamp.toDate()
      })) as QuizSubmission[];
    } catch (error) {
      console.error('Error fetching user submissions:', error);
      throw error;
    }
  }
};