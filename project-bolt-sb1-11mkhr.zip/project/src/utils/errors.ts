export class FirebaseError extends Error {
  constructor(
    message: string,
    public readonly code?: string,
    public readonly originalError?: unknown
  ) {
    super(message);
    this.name = 'FirebaseError';
  }
}

export class QuizSubmissionError extends FirebaseError {
  constructor(message: string, code?: string, originalError?: unknown) {
    super(message, code, originalError);
    this.name = 'QuizSubmissionError';
  }
}

export class AnalyticsError extends FirebaseError {
  constructor(message: string, code?: string, originalError?: unknown) {
    super(message, code, originalError);
    this.name = 'AnalyticsError';
  }
}