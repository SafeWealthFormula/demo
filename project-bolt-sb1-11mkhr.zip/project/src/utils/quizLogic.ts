import { UserAnswer, QuizFlag, QuizArea, FlagType } from '../types/quiz';
import { flagThresholds } from '../data/quizData';

export function determineFlag(area: QuizArea, answerId: string): FlagType {
  const thresholds = flagThresholds[area];
  
  if (thresholds.green.includes(answerId)) return 'green';
  if (thresholds.yellow1.includes(answerId)) return 'yellow1';
  if (thresholds.yellow2.includes(answerId)) return 'yellow2';
  return 'red';
}

export function analyzeFlaggedAreas(answers: UserAnswer[]): QuizFlag[] {
  const flags: QuizFlag[] = [];
  let priority = 1;

  // Map questions to areas
  const areaMap: Record<string, QuizArea> = {
    'QQ1': 'income',
    'QQ2': 'emergency',
    'QQ3': 'inflation'
  };

  // Analyze each answer
  answers.forEach(answer => {
    const area = areaMap[answer.questionId];
    if (!area) return;

    const answerId = answer.answerId[0]; // Use first answer for single-choice questions
    const flagType = determineFlag(area, answerId);

    flags.push({
      area,
      type: flagType,
      priority: priority++
    });
  });

  // Sort flags by severity (red -> yellow2 -> yellow1 -> green)
  return flags.sort((a, b) => {
    const severityOrder = { red: 0, yellow2: 1, yellow1: 2, green: 3 };
    return severityOrder[a.type] - severityOrder[b.type];
  });
}

export function getNextQuestion(flags: QuizFlag[], currentIndex: number) {
  // Get questions for current flag
  const currentFlag = flags[currentIndex];
  if (!currentFlag) return null;

  // Return appropriate question based on flag type
  return {
    flag: currentFlag,
    questionIndex: currentIndex
  };
}