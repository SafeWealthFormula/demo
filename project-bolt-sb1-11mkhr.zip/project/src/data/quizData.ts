import { Question } from '../types/quiz';

export const quickQuizData = {
  id: "quickQuiz",
  description: "Complete Quick Quiz (QQ1–QQ8) with all questions, tags, and flag mappings",
  questions: [
    {
      id: "QQ1",
      tag: "QQ1",
      text: "If your income stopped tomorrow, how long could you maintain your lifestyle?",
      type: "single",
      area: "income",
      answers: [
        { 
          id: "QQA1.1", 
          text: "More than 6 months—I have a solid safety net.",
          flag: "green"
        },
        { 
          id: "QQA1.2", 
          text: "3–6 months—I'd feel some strain but manage.",
          flag: "yellow1"
        },
        { 
          id: "QQA1.3", 
          text: "1–3 months—I'd need to make big adjustments.",
          flag: "yellow2"
        },
        { 
          id: "QQA1.4", 
          text: "Less than 1 month—I'd need immediate help.",
          flag: "red"
        }
      ]
    },
    // Add remaining questions...
  ]
};

export const standardQuizData = {
  id: "standardQuiz",
  description: "Standard Quiz with comprehensive financial assessment",
  questions: [
    // Add standard quiz questions...
  ]
};

export const extendedQuizData = {
  id: "extendedQuiz",
  description: "Extended Quiz based on flagged areas",
  questions: [
    // Add extended quiz questions...
  ]
};