import { Question } from '../types/quiz';

export const extendedQuizQuestions: Question[] = [
  // Income Resilience Questions
  {
    id: 'EQ1_RED',
    text: 'What would give you the most confidence in handling a long-term income disruption?',
    type: 'multiple',
    area: 'income',
    flag: 'red',
    order: 1,
    answers: [
      { id: 'EQA1.1', text: 'Knowing I have resources that grow even when I\'m not earning.' },
      { id: 'EQA1.2', text: 'Feeling assured my savings could cover a long-term challenge without running out.' },
      { id: 'EQA1.3', text: 'Having a backup plan that doesn\'t rely solely on savings.' },
      { id: 'EQA1.4', text: 'Knowing there are strategies I can use to strengthen my financial safety net.' }
    ]
  },
  {
    id: 'EQ1_RED_SEC',
    text: 'What\'s been your biggest challenge in creating a financial safety net?',
    type: 'multiple',
    area: 'income',
    flag: 'red',
    order: 2,
    isSecondary: true,
    answers: [
      { id: 'EQA1.5', text: 'I don\'t have extra income to save right now.' },
      { id: 'EQA1.6', text: 'I\'m unsure how to prioritize savings while managing expenses.' },
      { id: 'EQA1.7', text: 'I\'ve struggled to stay consistent with saving.' },
      { id: 'EQA1.8', text: 'I haven\'t started thinking about it seriously yet.' }
    ]
  },
  {
    id: 'EQ1_YELLOW2',
    text: 'What steps could help you feel more secure if your income were disrupted for an extended period?',
    type: 'single',
    area: 'income',
    flag: 'yellow2',
    order: 1,
    answers: [
      { id: 'EQA1.9', text: 'Building a larger savings cushion to cover several months of expenses.' },
      { id: 'EQA1.10', text: 'Finding ways to reduce my reliance on a single income source.' },
      { id: 'EQA1.11', text: 'Exploring financial tools to provide stability during disruptions.' },
      { id: 'EQA1.12', text: 'I\'m not sure, but having more than a few months\' income saved up seems wise.' }
    ]
  },
  {
    id: 'EQ1_YELLOW1',
    text: 'What adjustments would help you feel more prepared for unexpected financial disruptions?',
    type: 'multiple',
    area: 'income',
    flag: 'yellow1',
    order: 1,
    answers: [
      { id: 'EQA1.13', text: 'Finding ways to grow my savings while keeping them accessible.' },
      { id: 'EQA1.14', text: 'Adding strategies to handle simultaneous challenges.' },
      { id: 'EQA1.15', text: 'Creating a backup plan to protect my savings.' },
      { id: 'EQA1.16', text: 'I\'m confident my savings are sufficient.' }
    ]
  },
  {
    id: 'EQ1_GREEN',
    text: 'How do you plan to optimize your safety net for long-term wealth growth?',
    type: 'single',
    area: 'income',
    flag: 'green',
    order: 1,
    answers: [
      { id: 'EQA1.17', text: 'I\'m exploring ways to balance liquidity with higher returns on savings.' },
      { id: 'EQA1.18', text: 'I\'m focused on aligning my safety net with future retirement goals.' },
      { id: 'EQA1.19', text: 'I prefer a highly secure safety net and don\'t feel the need to optimize further.' },
      { id: 'EQA1.20', text: 'I haven\'t thought about optimizing my safety net beyond its current setup.' }
    ]
  }
];

export const flagThresholds = {
  income: {
    green: ['QQA1.1'],
    yellow1: ['QQA1.2'],
    yellow2: ['QQA1.3'],
    red: ['QQA1.4']
  },
  emergency: {
    green: ['QQA2.1'],
    yellow1: ['QQA2.2'],
    yellow2: ['QQA2.3'],
    red: ['QQA2.4']
  }
};