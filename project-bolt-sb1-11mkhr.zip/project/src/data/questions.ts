import { Question } from '../types/quiz';

export const quickQuizQuestions: Question[] = [
  {
    id: 'QQ1',
    text: 'If your income stopped tomorrow, how long could you maintain your current lifestyle?',
    type: 'single',
    answers: [
      { id: 'QQA1.1', text: 'More than 6 months—I have a solid safety net.' },
      { id: 'QQA1.2', text: '3–6 months—I\'d feel some strain but manage.' },
      { id: 'QQA1.3', text: '1–3 months—I\'d need to make big adjustments.' },
      { id: 'QQA1.4', text: 'Less than 1 month—I\'d need immediate help.' }
    ]
  },
  {
    id: 'QQ2',
    text: 'How would you handle a $5,000 unexpected expense today?',
    type: 'single',
    answers: [
      { id: 'QQA2.1', text: 'I\'d cover it easily with savings.' },
      { id: 'QQA2.2', text: 'I\'d manage but feel the pinch.' },
      { id: 'QQA2.3', text: 'I\'d need to rely on credit or help from others.' },
      { id: 'QQA2.4', text: 'I don\'t know how I\'d handle it right now.' }
    ]
  },
  {
    id: 'QQ3',
    text: 'What steps have you taken to manage inflation\'s impact on your savings?',
    type: 'single',
    answers: [
      { id: 'QQA3.1', text: 'I\'ve made specific adjustments to protect my savings.' },
      { id: 'QQA3.2', text: 'I\'ve started exploring options but haven\'t done much yet.' },
      { id: 'QQA3.3', text: 'I haven\'t adjusted for inflation but know I should.' },
      { id: 'QQA3.4', text: 'I\'m not sure how inflation affects my finances.' }
    ]
  },
  {
    id: 'QQ4',
    text: 'What portion of your monthly income do you save or invest?',
    type: 'single',
    answers: [
      { id: 'QQA4.1', text: 'More than 20%—I\'m building wealth actively.' },
      { id: 'QQA4.2', text: '10–20%—I\'m making steady progress.' },
      { id: 'QQA4.3', text: 'Less than 10%—I\'m working on improving my habits.' },
      { id: 'QQA4.4', text: 'None—I\'m focused on paying off debt or covering expenses.' }
    ]
  },
  {
    id: 'QQ5',
    text: 'How diversified is your investment portfolio?',
    type: 'single',
    answers: [
      { id: 'QQA5.1', text: 'Very diversified—my investments cover multiple asset types.' },
      { id: 'QQA5.2', text: 'Moderately diversified—I have some mix, but there\'s room to grow.' },
      { id: 'QQA5.3', text: 'Not diversified—I\'m heavily reliant on one area (e.g., stocks).' },
      { id: 'QQA5.4', text: 'I don\'t currently invest.' }
    ]
  },
  {
    id: 'QQ6',
    text: 'Do you have a plan to reduce taxes on your savings and investments?',
    type: 'single',
    answers: [
      { id: 'QQA6.1', text: 'Yes, I\'ve optimized my tax strategy effectively.' },
      { id: 'QQA6.2', text: 'I\'ve started but know there\'s room for improvement.' },
      { id: 'QQA6.3', text: 'No, I haven\'t considered how to reduce taxes.' },
      { id: 'QQA6.4', text: 'I\'m not sure how taxes affect my savings and investments.' }
    ]
  },
  {
    id: 'QQ7',
    text: 'Have you calculated how much money you\'ll need to retire comfortably?',
    type: 'single',
    answers: [
      { id: 'QQA7.1', text: 'Yes, I\'ve calculated my needs and feel I\'m on track.' },
      { id: 'QQA7.2', text: 'I\'ve done some planning but have not yet determined an exact figure.' },
      { id: 'QQA7.3', text: 'I haven\'t calculated it, but I know it\'s important.' },
      { id: 'QQA7.4', text: 'I don\'t know where to start with retirement planning.' }
    ]
  },
  {
    id: 'QQ8',
    text: 'What steps have you taken to ensure your family\'s financial security?',
    type: 'multiple',
    answers: [
      { id: 'QQA8.1', text: 'I\'ve created a will and trust to protect their future.' },
      { id: 'QQA8.2', text: 'I have life insurance but no formal estate plan.' },
      { id: 'QQA8.3', text: 'I\'ve started planning but haven\'t finalized anything.' },
      { id: 'QQA8.4', text: 'I haven\'t taken any steps yet, but I want to.' }
    ]
  }
];

export const standardQuizQuestions: Question[] = [
  {
    id: 'SQQ1',
    text: 'What concerns you most about your finances?',
    type: 'multiple',
    maxSelections: 2,
    answers: [
      { id: 'SQA1', text: 'Taxes.' },
      { id: 'SQA2', text: 'Inflation.' },
      { id: 'SQA3', text: 'Market volatility.' },
      { id: 'SQA4', text: 'Outliving my savings.' },
      { id: 'SQA5', text: 'Protecting my family/legacy.' }
    ]
  },
  {
    id: 'SQQ2',
    text: 'How confident are you in achieving your long-term financial goals?',
    type: 'single',
    answers: [
      { id: 'SQA1', text: 'Very confident—my plan is solid.' },
      { id: 'SQA2', text: 'Somewhat confident—I need some adjustments.' },
      { id: 'SQA3', text: 'Not confident—I need professional guidance.' }
    ]
  },
  {
    id: 'SQQ3',
    text: 'If an unexpected expense hit tomorrow, how financially prepared are you?',
    type: 'single',
    answers: [
      { id: 'SQA1', text: 'I have more than 6 months of expenses saved.' },
      { id: 'SQA2', text: 'I have 3–6 months of expenses saved.' },
      { id: 'SQA3', text: 'I have less than 3 months saved.' },
      { id: 'SQA4', text: 'I don\'t have any savings set aside.' }
    ]
  },
  {
    id: 'SQQ4',
    text: 'What portion of your income do you save or invest regularly?',
    type: 'single',
    answers: [
      { id: 'SQA1', text: 'More than 15%.' },
      { id: 'SQA2', text: '6–15%.' },
      { id: 'SQA3', text: '0–5%.' },
      { id: 'SQA4', text: 'I don\'t save or invest currently.' }
    ]
  },
  {
    id: 'SQQ5',
    text: 'Do you have a trusted financial advisor guiding your strategy?',
    type: 'single',
    answers: [
      { id: 'SQA1', text: 'Yes, I work with a professional advisor.' },
      { id: 'SQA2', text: 'No, I manage everything myself.' },
      { id: 'SQA3', text: 'I rely on informal advice (family/friends).' }
    ]
  },
  {
    id: 'SQQ6',
    text: 'How diversified is your portfolio across different types of investments?',
    type: 'single',
    answers: [
      { id: 'SQA1', text: 'Well-diversified (e.g., stocks, bonds, real estate, cash).' },
      { id: 'SQA2', text: 'Partially diversified (e.g., mostly stocks with some bonds or cash).' },
      { id: 'SQA3', text: 'Not diversified (e.g., concentrated in one area like stocks or crypto).' }
    ]
  },
  {
    id: 'SQQ7',
    text: 'Which of these tools are part of your financial plan?',
    type: 'multiple',
    answers: [
      { id: 'SQA1', text: '401(k)/403(b) (employer-sponsored retirement accounts).' },
      { id: 'SQA2', text: 'IRA/Roth IRA (individual retirement accounts).' },
      { id: 'SQA3', text: 'Brokerage accounts (non-retirement investments).' },
      { id: 'SQA4', text: 'Other (e.g., annuities, alternative investments).' },
      { id: 'SQA5', text: 'None of the above.' }
    ]
  },
  {
    id: 'SQQ8',
    text: 'Do you have a clear understanding of how much money you\'ll need to retire comfortably?',
    type: 'single',
    answers: [
      { id: 'SQA1', text: 'Yes, I\'ve calculated it precisely.' },
      { id: 'SQA2', text: 'Not exactly, but I have a rough idea.' },
      { id: 'SQA3', text: 'No, I haven\'t calculated it yet.' }
    ]
  },
  {
    id: 'SQQ9',
    text: 'When do you hope to retire?',
    type: 'single',
    answers: [
      { id: 'SQA1', text: 'Under 55 (early retirement).' },
      { id: 'SQA2', text: '55–59 (near-early retirement).' },
      { id: 'SQA3', text: '60–65 (traditional retirement age).' },
      { id: 'SQA4', text: 'Over 65.' },
      { id: 'SQA5', text: 'I\'m not sure yet.' }
    ]
  },
  {
    id: 'SQQ10',
    text: 'How prepared are you for major healthcare or long-term care expenses?',
    type: 'single',
    answers: [
      { id: 'SQA1', text: 'I have comprehensive coverage, including long-term care.' },
      { id: 'SQA2', text: 'I have basic health insurance but no specific long-term care plan.' },
      { id: 'SQA3', text: 'I rely on savings for unexpected costs.' },
      { id: 'SQA4', text: 'I haven\'t started planning for medical expenses yet.' }
    ]
  },
  {
    id: 'SQQ11',
    text: 'What steps have you taken to protect your family and legacy?',
    type: 'multiple',
    answers: [
      { id: 'SQA1', text: 'I\'ve created a will to outline my wishes.' },
      { id: 'SQA2', text: 'I\'ve established a trust to secure asset distribution.' },
      { id: 'SQA3', text: 'I rely on life insurance for financial protection.' },
      { id: 'SQA4', text: 'I haven\'t taken any steps yet.' }
    ]
  },
  {
    id: 'SQQ12',
    text: 'How confident are you that your wealth is protected against inflation?',
    type: 'single',
    answers: [
      { id: 'SQA1', text: 'I\'ve actively invested in inflation-protected strategies.' },
      { id: 'SQA2', text: 'I\'m somewhat confident but haven\'t specifically addressed inflation.' },
      { id: 'SQA3', text: 'I\'m not confident; I rely on cash or fixed-income investments.' }
    ]
  }
];