import { FirestoreTimestamp } from '../services/firestore/schemas';

export type QuizType = 'quick' | 'standard' | 'extended';
export type FlagType = 'green' | 'yellow1' | 'yellow2' | 'red';
export type QuizArea = 'income' | 'emergency' | 'inflation' | 'savings' | 'advisor' | 'portfolio' | 'retirement' | 'legacy';

export interface Answer {
  id: string;
  text: string;
}

export interface Question {
  id: string;
  text: string;
  type: 'single' | 'multiple';
  answers: Answer[];
  maxSelections?: number;
  area?: QuizArea;
  flag?: FlagType;
  order?: number;
  isSecondary?: boolean;
}

export interface UserAnswer {
  questionId: string;
  answerId: string[];
  timestamp?: FirestoreTimestamp;
}

export interface QuizFlag {
  area: QuizArea;
  type: FlagType;
  priority: number;
}

export interface UserInfo {
  email?: string;
  phone?: string;
  quizType?: QuizType;
  flags?: QuizFlag[];
}

export interface QuizSection {
  title: string;
  description: string;
  questions: Question[];
}