import { useState, useEffect } from 'react';
import { initializeFirestore } from '../services/firestore/initialize';

export function useFirestore() {
  const [isInitialized, setIsInitialized] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const initialize = async () => {
      try {
        const success = await initializeFirestore();
        if (!success) {
          throw new Error('Failed to initialize Firestore');
        }
        setIsInitialized(true);
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to initialize database';
        setError(errorMessage);
        console.error('Database initialization error:', err);
      }
    };

    initialize();
  }, []);

  return { isInitialized, error };
}