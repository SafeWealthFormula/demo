import { useState, useEffect } from 'react';
import { quizFlowService, QuizFlow } from '../services/firestore/quizFlowService';
import { useQuizStore } from '../store/quizStore';

export function useQuizFlow(userId: string) {
  const [quizFlow, setQuizFlow] = useState<QuizFlow | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { userAnswers, userInfo } = useQuizStore();

  useEffect(() => {
    const loadQuizFlow = async () => {
      if (!userId) return;

      setIsLoading(true);
      setError(null);

      try {
        // Check if flow exists
        let flow = await quizFlowService.getUserQuizFlow(userId);

        // If no flow exists and we have flags, compute it
        if (!flow && userInfo.flags) {
          await quizFlowService.computeQuizFlow(
            userId,
            userInfo.flags,
            userAnswers
          );
          flow = await quizFlowService.getUserQuizFlow(userId);
        }

        setQuizFlow(flow);
      } catch (err) {
        setError('Failed to load quiz flow');
        console.error('Error loading quiz flow:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadQuizFlow();
  }, [userId, userAnswers, userInfo.flags]);

  return {
    quizFlow,
    isLoading,
    error
  };
}