import { useState, useEffect } from 'react';
import { extendedQuizService } from '../services/firestore/extendedQuizService';
import { Question } from '../types/quiz';
import { useQuizStore } from '../store/quizStore';

export function useExtendedQuiz() {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const currentQuestionIndex = useQuizStore(state => state.currentQuestionIndex);

  useEffect(() => {
    const loadQuestions = async () => {
      setIsLoading(true);
      setError(null);

      try {
        const loadedQuestions = await extendedQuizService.getExtendedQuestions();
        setQuestions(loadedQuestions);
      } catch (err) {
        setError('Failed to load extended quiz questions');
        console.error('Error loading extended quiz:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadQuestions();
  }, []);

  const currentQuestion = questions[currentQuestionIndex];
  const totalQuestions = questions.length;
  const isComplete = currentQuestionIndex >= totalQuestions;

  return {
    currentQuestion,
    currentQuestionIndex,
    totalQuestions,
    isComplete,
    isLoading,
    error
  };
}