import { useState } from 'react';
import { analyticsService } from '../services/firestore';
import { AnalyticsError } from '../utils/errors';

export function useAnalytics() {
  const [isTracking, setIsTracking] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const trackEvent = async (
    type: string,
    data: Record<string, any>
  ) => {
    setIsTracking(true);
    setError(null);

    try {
      await analyticsService.trackEvent(type, data);
    } catch (err) {
      const error = err instanceof AnalyticsError 
        ? err 
        : new AnalyticsError('Failed to track event', undefined, err);
      
      setError(error.message);
      throw error;
    } finally {
      setIsTracking(false);
    }
  };

  return {
    trackEvent,
    isTracking,
    error
  };
}